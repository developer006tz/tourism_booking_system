
<?php $__env->startSection('web_title'); ?>
    Tour sites
<?php $__env->stopSection(); ?>
<?php $__env->startSection('web_content'); ?>
<div class="contaner mt-4" style="margin-top:20px;height:20px;width:100%;"></div>
    <!-- Tours Start -->
    <div class="container-xxl my-4 py-5">
        <div class="container">
            <div class="text-center wow fadeInUp mb-4" data-wow-delay="0.1s">
                <h6 class="section-title bg-white text-center text-primary px-3"> <?php echo e($toursite->name ?? '-'); ?></h6>
                
                
            </div>

            <div class="row g-4 text-left wow fadeInUp mb-4" data-wow-delay="0.1s">
               
                <div class="description">
                    <p><?php echo e($toursite->description ?? '-'); ?></p>
                </div>
                
            </div>
            <div class="row g-4 text-left wow fadeInUp mb-4" data-wow-delay="0.1s">
                <div class="description">
                    <b>Country | Region | District | Distance from region</b>
                    <p> <?php echo e($toursite->name ?? '-'); ?> is located in <?php echo e($toursite->country->name ?? '-'); ?> , <?php echo e($toursite->region ?? '-'); ?> in  <?php echo e($toursite->district ?? '-'); ?> district. The distance from <?php echo e($toursite->region ?? '-'); ?> town to The Site is <?php echo e($toursite->distance. ' KM' ?? '-'); ?></p>
                </div>
            </div>

            <div class="row g-4 text-left wow fadeInUp mb-4" data-wow-delay="0.1s">
                <div class="description">
                    <b>Attractions</b>
                    <p><?php echo e($toursite->attractions ?? '-'); ?></p>
                </div>
            </div>

            <div class="row g-4 text-left wow fadeInUp mb-4" data-wow-delay="0.1s">
                <div class="description">
                    <b>Best time to visit</b>
                    <p><?php echo e($toursite->time_of_visit ?? '-'); ?></p>
                </div>
            </div>

            <div class="row g-4 text-left wow fadeInUp mb-4" data-wow-delay="0.1s">
               
                <div class="description">
                    <b>Accomodations</b>
                    <p><?php echo e($toursite->accomodation ?? '-'); ?></p>
                </div>
                
            </div>

            <div class="row g-4 text-left wow fadeInUp mb-4" data-wow-delay="0.1s">
               
                <div class="description">
                    <b>Fees</b>
                    <p>For Local citizens the fees to enter park is <b class="text-primary" ><?php echo e($toursite->local_price.' Tsh' ?? '0'); ?></b>  and for international Tourists the fees is <b class="text-primary" ><?php echo e($toursite->international_price.' USD' ?? '0'); ?></b></p>
                </div>
                
            </div>
            <div class="row g-4 justify-content-left">
                
                <?php $__empty_1 = true; $__currentLoopData = $toursite->allToursiteimages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $toursiteimage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                
                        <div class="col-3 wow zoomIn" data-wow-delay="0.3s">
                            <a class="position-relative d-block overflow-hidden" href="">
                                <img class="img-fluid" src="<?php echo e($toursiteimage->image ? url(\Storage::url($toursiteimage->image)) : ''); ?>" alt="">
                            </a>
                        </div>
                    
            
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                
                <p>no images yet</p>
                </div>
                <?php endif; ?>
                
            </div>

             <div class="row my-4 d-flex">
                    
                    <div class="col-md-6">
                        <a href="<?php echo e(route('tour.sites')); ?>" class="btn btn-primary text-right">Back</a>
                    </div>
                    <div class="col-md-6">
                        <h6 class="text-left"></h6>
                    </div>
                </div>
        </div>
    </div>
    <!-- Package End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\tour\resources\views/web/single_tour_site.blade.php ENDPATH**/ ?>