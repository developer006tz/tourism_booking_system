<div class="col-md-6">
                <form>
                    <div class="input-group">
                        <input
                            id="indexSearch"
                            type="text"
                            name="search"
                            placeholder="<?php echo e(__('crud.common.search')); ?>"
                            value="<?php echo e($search ?? ''); ?>"
                            class="form-control"
                            autocomplete="off"
                            required
                        />
                        <div class="input-group-append">
                            <button type="submit" class="btn btn-primary">
                                <i class="icon ion-md-search"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div><?php /**PATH C:\xampp\htdocs\project\tour\resources\views/components/search.blade.php ENDPATH**/ ?>