<div class="sidebar" id="sidebar">
			<div class="sidebar-inner slimscroll">
				<div id="sidebar-menu" class="sidebar-menu">
					<ul>
						<?php if(auth()->guard()->check()): ?>
						<li class="<?php echo e(getActive('home')); ?>"> <a href="<?php echo e(route('home')); ?>"><i class="fas fa-tachometer-alt"></i> <span>Dashboard</span></a> </li>
						<li class="list-divider"></li>
						<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-any', App\Models\Toursite::class)): ?>
						<li class="submenu"> <a href="#"><i class="fa fa-map"></i> <span> Toursites </span> <span class="menu-arrow"></span></a>
							<ul class="submenu_class " style="display: none;">
								<li class="<?php echo e(activeMenu('toursites.index')); ?>" ><a href="<?php echo e(route('toursites.index')); ?>"> view </a></li>
								<li  class="<?php echo e(activeMenu('toursites.create')); ?>"><a href="<?php echo e(route('toursites.create')); ?>"> add </a></li>
								<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-any', App\Models\Toursiteimages::class)): ?>
								<li  class="<?php echo e(activeMenu('all-toursiteimages.create')); ?>"><a href="<?php echo e(route('all-toursiteimages.create')); ?>"> add photo </a></li>
								<li class="<?php echo e(activeMenu('all-toursiteimages.index')); ?>" ><a href="<?php echo e(route('all-toursiteimages.index')); ?>"> view photos</a></li>
							
						<?php endif; ?>
							</ul>
						</li>
						<?php endif; ?>

						 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-any', App\Models\Attractions::class)): ?>
						<li class="submenu"> <a href="#" class="<?php echo e(getActive('all-attractions','subdrop')); ?>"><i class="fas fa-map-marked-alt"></i> <span> Attractions </span> <span class="menu-arrow"></span></a>
							<ul class="submenu_class" style="display: none;">
								<li><a class="<?php echo e(getActive('all-attractions.index')); ?>" href="<?php echo e(route('all-attractions.index')); ?>"> view </a></li>
								<li><a class="<?php echo e(getActive('all-attractions.create')); ?>" href="<?php echo e(route('all-attractions.index')); ?>"> add </a></li>
								<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-any', App\Models\Attractionimages::class)): ?>
								<li><a class="<?php echo e(getActive('all-attractionimages.create')); ?>" href="<?php echo e(route('all-attractionimages.create')); ?>"> add photo </a></li>
								<li><a class="<?php echo e(getActive('all-attractionimages.index')); ?>" href="<?php echo e(route('all-attractionimages.index')); ?>"> view photos</a></li>
							
						<?php endif; ?>
							</ul>
						</li>
						<?php endif; ?>
						 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-any', App\Models\Booking::class)): ?>
						<li class="submenu"> <a href="#"><i class="far fa-address-book"></i><span> Bookings </span> <span class="menu-arrow"></span></a>
							<ul class="submenu_class" style="display: none;">
								<li><a href="<?php echo e(route('bookings.index')); ?>"> view</a></li>
							</ul>
						</li>
						<?php endif; ?>
						 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-any', App\Models\Country::class)): ?>
						<li class="submenu"> <a href="#"><i class="fas fa-flag"></i> <span> Countries </span> <span class="menu-arrow"></span></a>
							<ul class="submenu_class" style="display: none;">
								<li><a href="<?php echo e(route('countries.create')); ?>"> add </a></li>
								<li><a href="<?php echo e(route('countries.index')); ?>"> view</a></li>
							</ul>
						</li>
						<?php endif; ?>
						<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-any', App\Models\Accomodations::class)): ?>
						<li class="submenu"> <a href="#"><i class="fas fa-hotel"></i> <span> Accomodations </span> <span class="menu-arrow"></span></a>
							<ul class="submenu_class" style="display: none;">
								<li><a href="<?php echo e(route('all-accomodationimages.index')); ?>"> add </a></li>
								<li><a href="<?php echo e(route('all-accomodations.index')); ?>"> view</a></li>
								<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-any', App\Models\Accomodationimages::class)): ?>
								<li><a href="<?php echo e(route('all-accomodationimages.index')); ?>"> add image</a></li>
								<li><a href="<?php echo e(route('all-accomodations.index')); ?>"> view images</a></li>
								<?php endif; ?>
							</ul>
						</li>
						<?php endif; ?>
					
						<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-any', App\Models\Transportation::class)): ?>
						<li class="submenu"> <a href="#"><i class="fas fa-plane-departure"></i> <span> Transportations </span> <span class="menu-arrow"></span></a>
							<ul class="submenu_class" style="display: none;">
								<li><a href="<?php echo e(route('all-transportation.create')); ?>"> add </a></li>
								<li><a href="<?php echo e(route('all-transportation.index')); ?>"> view</a></li>
							</ul>
						</li>
						<?php endif; ?>
						<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-any', App\Models\Tourguide::class)): ?>
						<li class="submenu"> <a href="#"><i class="fas fa-user-tie"></i></i> <span> Tour Guides </span> <span class="menu-arrow"></span></a>
							<ul class="submenu_class" style="display: none;">
								<li><a href="<?php echo e(route('tourguideagents.create')); ?>"> add </a></li>
								<li><a href="<?php echo e(route('tourguideagents.index')); ?>"> view</a></li>
							</ul>
						</li>
						<?php endif; ?>
						<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-any', App\Models\User::class)): ?>
						<li class="submenu"> <a href="#"><i class="fas fa-user-edit fa-spin"></i> <span> Manage Users </span> <span class="menu-arrow"></span></a>
							<ul class="submenu_class" style="display: none;">
								<li><a href="<?php echo e(route('users.create')); ?>"> add </a></li>
								<li><a href="<?php echo e(route('users.index')); ?>"> view</a></li>
							</ul>
						</li>
						<?php endif; ?>
						<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-any', App\Models\Tourchallenges::class)): ?>
						<li class="submenu"> <a href="#"><i class="fas fa-paste"></i></i> <span> Tour challenges </span> <span class="menu-arrow"></span></a>
							<ul class="submenu_class" style="display: none;">
								<li><a href="<?php echo e(route('all-tourchallenges.index')); ?>"> add </a></li>
								<li><a href="<?php echo e(route('all-tourchallenges.index')); ?>"> view</a></li>
							</ul>
						</li>
						<?php endif; ?>
						<?php if(Auth::user()->can('view-any', Spatie\Permission\Models\Role::class) || 
                    Auth::user()->can('view-any', Spatie\Permission\Models\Permission::class)): ?>
						<li class="submenu"> <a href="#"><i class="fas fa-user-lock"></i> <span> Access Management </span> <span class="menu-arrow"></span></a>
							 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-any', Spatie\Permission\Models\Role::class)): ?>
							<ul class="submenu_class" style="display: none;">
								<li><a href="<?php echo e(route('all-toursiteimages.index')); ?>"> Roles </a></li>
								<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-any', Spatie\Permission\Models\Permission::class)): ?>
								<li><a href="<?php echo e(route('all-toursiteimages.index')); ?>"> Permissions</a></li>
								<?php endif; ?>
							</ul>
							<?php endif; ?>
						</li>
						<?php endif; ?>
						<li class="my-4" style="height:10px;"></li>
						<?php endif; ?>
					</ul>
				</div>
			</div>
		</div><?php /**PATH C:\xampp\htdocs\project\tour\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>