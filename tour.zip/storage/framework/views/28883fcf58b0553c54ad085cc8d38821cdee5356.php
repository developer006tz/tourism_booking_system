<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
	<title>Tour admin</title>
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('logo.jpg')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/bootstrap.min.css')); ?>">
	
	<link rel="stylesheet" href="<?php echo e(asset('admin/assets/plugins/fontawesome/css/all.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/feathericon.min.css')); ?>">
	<link rel="stylehseet" href="<?php echo e(asset('admin/https://cdn.oesmith.co.uk/morris-0.5.1.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('admin/assets/plugins/morris/morris.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/style.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/clearfix.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/select2.min.css')); ?>">
    <script src="https://unpkg.com/alpinejs@3.10.2/dist/cdn.min.js" defer></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.css">
        
        <!-- Icons -->
        <link href="https://unpkg.com/ionicons@4.5.10-0/dist/css/ionicons.min.css" rel="stylesheet">
 </head>
<script type="module">
            import hotwiredTurbo from 'https://cdn.skypack.dev/@hotwired/turbo';
        </script>
        
        <?php echo \Livewire\Livewire::styles(); ?>

<body>
	<div class="main-wrapper">
		<div class="header">
		 <?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
		<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<div class="page-wrapper">
			<?php echo $__env->yieldContent('content'); ?>
		</div>
	</div>
    <?php echo $__env->yieldPushContent('modals'); ?>
       
	
	<script src="<?php echo e(asset('admin/assets/js/jquery-3.5.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('admin/assets/js/popper.min.js')); ?>"></script>
	<script src="<?php echo e(asset('admin/assets/js/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('admin/assets/plugins/slimscroll/jquery.slimscroll.min.js')); ?>"></script>
	<script src="<?php echo e(asset('admin/assets/plugins/raphael/raphael.min.js')); ?>"></script>
	<script src="<?php echo e(asset('admin/assets/plugins/morris/morris.min.js')); ?>"></script>
	<script src="<?php echo e(asset('admin/assets/js/chart.morris.js')); ?>"></script>
	<script src="<?php echo e(asset('admin/assets/js/script.js')); ?>"></script>
	<script src="<?php echo e(asset('admin/assets/js/select2.min.js')); ?>"></script>
        <script src="https://cdn.jsdelivr.net/gh/livewire/turbolinks@v0.1.x/dist/livewire-turbolinks.js" data-turbolinks-eval="false" data-turbo-eval="false"></script>
        <?php echo \Livewire\Livewire::scripts(); ?>

        <?php echo $__env->yieldPushContent('scripts'); ?>
        
        <script src="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.js"></script>
        
        <?php if(session()->has('success')): ?> 
        <script>
            var notyf = new Notyf({dismissible: true})
            notyf.success('<?php echo e(session('success')); ?>')
        </script> 
        <?php endif; ?>
    <script>
           /* Simple Alpine Image Viewer */
document.addEventListener('alpine:init', () => {
    Alpine.data('imageViewer', (src = '') => {
        return {
            imageUrls: src ? [src] : [],

            refreshUrl() {
                this.imageUrls = this.$el.getAttribute('image-url');
            },

            filesChosen(event) {
                this.imageUrls = [];
                const files = event.target.files;
                for (let i = 0; i < files.length; i++) {
                    const fileReader = new FileReader();
                    fileReader.onload = (event) => {
                        this.imageUrls.push(event.target.result);
                    };
                    fileReader.readAsDataURL(files[i]);
                }
            },
        };
    });
});
</script>

<script>
    //initialize select2
    $(function () {
        $('.select2').select2({
            placeholder: 'Select a category'
        });
    });
</script>
</body>

</html><?php /**PATH C:\xampp\htdocs\project\tour\resources\views/layouts/app.blade.php ENDPATH**/ ?>