<label class="<?php echo e(($required ?? false) ? 'label label-required ' : 'label '); ?>" for="<?php echo e($name); ?>">
    <?php echo e($label); ?>

</label><?php /**PATH C:\xampp\htdocs\project\tour\resources\views/components/inputs/partials/label.blade.php ENDPATH**/ ?>