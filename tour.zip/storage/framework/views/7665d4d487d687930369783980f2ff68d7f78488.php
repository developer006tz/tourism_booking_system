<?php $__env->startSection('content'); ?>
<div class="content container-fluid">
    <div class="searchbar mb-4">
        <div class="row">
             <?php echo $__env->make('components.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col-md-6 text-right">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\Accomodations::class)): ?>
                <a
                    href="<?php echo e(route('all-accomodations.create')); ?>"
                    class="btn btn-primary"
                >
                    <i class="icon ion-md-add"></i> <?php echo app('translator')->get('crud.common.create'); ?>
                </a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div style="display: flex; justify-content: space-between;">
                <h4 class="card-title">
                    <?php echo app('translator')->get('crud.all_accomodations.index_title'); ?>
                </h4>
            </div>

            <div class="table-responsive">
                <table class="table table-borderless table-hover">
                    <thead>
                        <tr>
                            <th class="text-left">
                                <?php echo app('translator')->get('crud.all_accomodations.inputs.toursite_id'); ?>
                            </th>
                            <th class="text-left">
                                <?php echo app('translator')->get('crud.all_accomodations.inputs.name'); ?>
                            </th>
                            <th class="text-left">
                                <?php echo app('translator')->get('crud.all_accomodations.inputs.type'); ?>
                            </th>
                            <th class="text-left">
                                <?php echo app('translator')->get('crud.all_accomodations.inputs.sleep_service'); ?>
                            </th>
                            <th class="text-left">
                                <?php echo app('translator')->get('crud.all_accomodations.inputs.description'); ?>
                            </th>
                            <th class="text-right">
                                <?php echo app('translator')->get('crud.all_accomodations.inputs.local_night_fee'); ?>
                            </th>
                            <th class="text-right">
                                <?php echo app('translator')->get('crud.all_accomodations.inputs.international_night_fee'); ?>
                            </th>
                            <th class="text-left">
                                <?php echo app('translator')->get('crud.all_accomodations.inputs.food_service'); ?>
                            </th>
                            <th class="text-left">
                                <?php echo app('translator')->get('crud.all_accomodations.inputs.food_types_and_price'); ?>
                            </th>
                            <th class="text-left">
                                <?php echo app('translator')->get('crud.all_accomodations.inputs.is_inside_park'); ?>
                            </th>
                            <th class="text-right">
                                <?php echo app('translator')->get('crud.all_accomodations.inputs.distance_to_tour_site'); ?>
                            </th>
                            <th class="text-right">
                                <?php echo app('translator')->get('crud.all_accomodations.inputs.room_available'); ?>
                            </th>
                            <th class="text-center">
                                <?php echo app('translator')->get('crud.common.actions'); ?>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $allAccomodations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accomodations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <?php echo e(optional($accomodations->toursite)->name ??
                                '-'); ?>

                            </td>
                            <td><?php echo e($accomodations->name ?? '-'); ?></td>
                            <td><?php echo e($accomodations->type ?? '-'); ?></td>
                            <td><?php echo e($accomodations->sleep_service ?? '-'); ?></td>
                            <td><?php echo e($accomodations->description ?? '-'); ?></td>
                            <td>
                                <?php echo e($accomodations->local_night_fee ?? '-'); ?>

                            </td>
                            <td>
                                <?php echo e($accomodations->international_night_fee ??
                                '-'); ?>

                            </td>
                            <td><?php echo e($accomodations->food_service ?? '-'); ?></td>
                            <td>
                                <?php echo e($accomodations->food_types_and_price ?? '-'); ?>

                            </td>
                            <td><?php echo e($accomodations->is_inside_park ?? '-'); ?></td>
                            <td>
                                <?php echo e($accomodations->distance_to_tour_site ?? '-'); ?>

                            </td>
                            <td><?php echo e($accomodations->room_available ?? '-'); ?></td>
                            <td class="text-center" style="width: 134px;">
                                <div
                                    role="group"
                                    aria-label="Row Actions"
                                    class="btn-group"
                                >
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $accomodations)): ?>
                                    <a
                                        href="<?php echo e(route('all-accomodations.edit', $accomodations)); ?>"
                                    >
                                        <button
                                            type="button"
                                            class="btn btn-light"
                                        >
                                            <i class="icon ion-md-create"></i>
                                        </button>
                                    </a>
                                    <?php endif; ?> <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', $accomodations)): ?>
                                    <a
                                        href="<?php echo e(route('all-accomodations.show', $accomodations)); ?>"
                                    >
                                        <button
                                            type="button"
                                            class="btn btn-light"
                                        >
                                            <i class="icon ion-md-eye"></i>
                                        </button>
                                    </a>
                                    <?php endif; ?> <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $accomodations)): ?>
                                    <form
                                        action="<?php echo e(route('all-accomodations.destroy', $accomodations)); ?>"
                                        method="POST"
                                        onsubmit="return confirm('<?php echo e(__('crud.common.are_you_sure')); ?>')"
                                    >
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button
                                            type="submit"
                                            class="btn btn-light text-danger"
                                        >
                                            <i class="icon ion-md-trash"></i>
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="13">
                                <?php echo app('translator')->get('crud.common.no_items_found'); ?>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="13">
                                <?php echo $allAccomodations->render(); ?>

                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\tour\resources\views/app/all_accomodations/index.blade.php ENDPATH**/ ?>