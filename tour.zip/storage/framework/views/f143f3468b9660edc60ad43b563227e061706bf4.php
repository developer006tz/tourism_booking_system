
<?php $__env->startSection('web_title'); ?>
    Contact us
<?php $__env->stopSection(); ?>
<?php $__env->startSection('web_content'); ?>
    
    
    <div class="contaner mt-4" style="margin-top:20px;height:20px;width:100%;"></div>
    <!-- Tours Start -->
    <div class="container-xxl my-4 py-5">
        <div class="container">
            <div class="text-center wow fadeInUp mb-4" data-wow-delay="0.1s">
                <h6 class="section-title bg-white text-center text-primary px-3"> Contact Us (in construction.......)</h6>
                
                
            </div>

            <div class="row g-4 text-left wow fadeInUp mb-4" data-wow-delay="0.1s">
               
                <div class="description">
                    <p>For any question or suggestion please contact us through the following contacts:</p>
                    <p><b>Phone:</b> +255 754 000 000</p>
                    <p><b>Email:</b>
                        <a href="mailto:info@tour.com">info@tour.com</a>
                    </p>
                    <p><b>Address:</b> P.O.Box 0000, Dar es salaam, Tanzania</p>
                </div>

            </div>
        </div>
    </div>
    <!-- Tours End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\tour\resources\views/web/contact_us.blade.php ENDPATH**/ ?>