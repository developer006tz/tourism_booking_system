<div <?php echo e($attributes->merge(['class' => 'form-group'])); ?>>
    <?php echo e($slot); ?>

</div><?php /**PATH C:\xampp\htdocs\project\tour\resources\views/components/inputs/group.blade.php ENDPATH**/ ?>