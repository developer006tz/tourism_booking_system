<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">
                <a href="<?php echo e(route('toursites.index')); ?>" class="mr-4"
                    ><i class="icon ion-md-arrow-back"></i
                ></a>
                <?php echo app('translator')->get('crud.toursites.show_title'); ?>
            </h4>

            <div class="mt-4">
                <div class="mb-4">
                    <h5><?php echo app('translator')->get('crud.toursites.inputs.name'); ?></h5>
                    <span><?php echo e($toursite->name ?? '-'); ?></span>
                </div>
                <div class="mb-4">
                    <h5><?php echo app('translator')->get('crud.toursites.inputs.country_id'); ?></h5>
                    <span><?php echo e(optional($toursite->country)->name ?? '-'); ?></span>
                </div>
                <div class="mb-4">
                    <h5><?php echo app('translator')->get('crud.toursites.inputs.other_name'); ?></h5>
                    <span><?php echo e($toursite->other_name ?? '-'); ?></span>
                </div>
                <div class="mb-4">
                    <h5><?php echo app('translator')->get('crud.toursites.inputs.description'); ?></h5>
                    <span><?php echo e($toursite->description ?? '-'); ?></span>
                </div>
                <div class="mb-4">
                    <h5><?php echo app('translator')->get('crud.toursites.inputs.accomodation'); ?></h5>
                    <span><?php echo e($toursite->accomodation ?? '-'); ?></span>
                </div>
                <div class="mb-4">
                    <h5><?php echo app('translator')->get('crud.toursites.inputs.region'); ?></h5>
                    <span><?php echo e($toursite->region ?? '-'); ?></span>
                </div>
                <div class="mb-4">
                    <h5><?php echo app('translator')->get('crud.toursites.inputs.district'); ?></h5>
                    <span><?php echo e($toursite->district ?? '-'); ?></span>
                </div>
                <div class="mb-4">
                    <h5><?php echo app('translator')->get('crud.toursites.inputs.distance'); ?></h5>
                    <span><?php echo e($toursite->distance ?? '-'); ?></span>
                </div>
                <div class="mb-4">
                    <h5><?php echo app('translator')->get('crud.toursites.inputs.attractions'); ?></h5>
                    <span><?php echo e($toursite->attractions ?? '-'); ?></span>
                </div>
                <div class="mb-4">
                    <h5><?php echo app('translator')->get('crud.toursites.inputs.local_price'); ?></h5>
                    <span><?php echo e($toursite->local_price ?? '-'); ?></span>
                </div>
                <div class="mb-4">
                    <h5><?php echo app('translator')->get('crud.toursites.inputs.international_price'); ?></h5>
                    <span><?php echo e($toursite->international_price ?? '-'); ?></span>
                </div>
                <div class="mb-4">
                    <h5><?php echo app('translator')->get('crud.toursites.inputs.time_of_visit'); ?></h5>
                    <span><?php echo e($toursite->time_of_visit ?? '-'); ?></span>
                </div>
            </div>

            <div class="mt-4">
                <a href="<?php echo e(route('toursites.index')); ?>" class="btn btn-light">
                    <i class="icon ion-md-return-left"></i>
                    <?php echo app('translator')->get('crud.common.back'); ?>
                </a>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\Toursite::class)): ?>
                <a href="<?php echo e(route('toursites.create')); ?>" class="btn btn-light">
                    <i class="icon ion-md-add"></i> <?php echo app('translator')->get('crud.common.create'); ?>
                </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\tour\resources\views/app/toursites/show.blade.php ENDPATH**/ ?>