
<?php $__env->startSection('web_title'); ?>
    Tour sites
<?php $__env->stopSection(); ?>
<?php $__env->startSection('web_content'); ?>
<div class="contaner mt-4" style="margin-top:20px;height:20px;width:100%;"></div>
    <!-- Tours Start -->
    <div class="container-xxl my-4 py-5">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                <h6 class="section-title bg-white text-center text-primary px-3">Tourist sites</h6>
                
                <div class="row my-4">
                    <div class="col-md-6">
                        <h1 class="text-center">Tourist sites</h1>
                    </div>
                    <div class="col-md-6">
                        <form>
                            <div class="input-group">
                                <input type="text" name="search" value="<?php echo e($search ?? ''); ?>"  class="form-control" placeholder="Search for tourist sites" autocomplete="off" required>
                                <span class="input-group-btn">
                                    <button type="submit" class="btn btn-primary">Search</button>
                                </span>
                            </div>
                        </form>
                    </div>
                </div>

                
            </div>
            <div class="row g-4 justify-content-center">
                <?php $__empty_1 = true; $__currentLoopData = $toursites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $toursite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="package-item">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="<?php echo e($toursite->allToursiteimages ? url(\Storage::url($toursite->allToursiteimages->first()->image)) : ''); ?>" alt="<?php echo e($toursite->name ?? '-'); ?>">
                        </div>
                        <div class="d-flex border-bottom">
                            <small class="flex-fill text-center border-end py-2"><i class="fas fa-globe-africa text-primary me-2"></i> <?php echo e($toursite->country->name ?? '-'); ?></small>
                            <small class="flex-fill text-center border-end py-2"><i class="fa fa-map-marker-alt text-primary me-2"></i> <?php echo e($toursite->region ?? '-'); ?></small>
                            <small class="flex-fill text-center py-2"><i class="fas fa-map-marked-alt me-2"></i><?php echo e($toursite->distance ?? '-'); ?> Km</small>
                        </div>
                        <div class="text-center p-4">
                            <h3 class="mb-0"> <?php echo e($toursite->name ?? '-'); ?> </h3>
                            
                            <p><?php echo e(Str::limit($toursite->description,150) ?? '-'); ?> </p>
                            <div class="d-flex justify-content-center mb-2">
                                <a href="<?php echo e(route('tour_site.show', $toursite)); ?>" class="btn btn-sm btn-primary px-3 border-end" style="border-radius: 30px 0 0 30px;">Read More</a>
                                <a href="#" class="btn btn-sm btn-primary px-3" style="border-radius: 0 30px 30px 0;">Book Now</a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                
                <div class="row my-4 d-flex">
                    
                    <div class="col-md-6">
                        <a href="<?php echo e(route('tour.sites')); ?>" class="btn btn-primary text-right">Back</a>
                    </div>
                    <div class="col-md-6">
                        <h6 class="text-left">No Sites Added Yet..</h6>
                    </div>
                </div>
            </div>
                <?php endif; ?>

                
            </div>
        </div>
    </div>
    <!-- Package End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\tour\resources\views/web/tour_sites.blade.php ENDPATH**/ ?>